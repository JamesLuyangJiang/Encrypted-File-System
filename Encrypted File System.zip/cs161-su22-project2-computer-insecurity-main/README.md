[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=8152958&assignment_repo_type=AssignmentRepo)
# Project 2 Starter Code

This repository contains the starter code for Project 2!

For comprehensive documentation, see the Project 2 Spec (https://cs161.org/proj2/getting-started-coding/).

Write your implementation in `client/client.go`, and your tests in `client_test/client_test.go`.

To test your implementation, run `go test -v` inside of the `client_test` directory.
